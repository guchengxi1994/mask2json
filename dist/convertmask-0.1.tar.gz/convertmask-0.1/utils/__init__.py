'''
@lanhuage: python
@Descripttion: 
@version: beta
@Author: xiaoshuyui
@Date: 2020-07-10 10:09:56
@LastEditors: xiaoshuyui
@LastEditTime: 2020-07-10 10:10:21
'''
__version__ = '0.1'